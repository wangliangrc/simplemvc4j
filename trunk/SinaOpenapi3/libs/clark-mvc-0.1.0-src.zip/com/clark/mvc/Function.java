package com.clark.mvc;

interface Function {

    void onNotification(Notification notification);

}
