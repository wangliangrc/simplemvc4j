package com.clark.mvc;

public interface Proxy {

    String getProxyName();

}
