package com.clark.mvc;

public interface UIWorker {

    void postTask(Runnable task);

}
