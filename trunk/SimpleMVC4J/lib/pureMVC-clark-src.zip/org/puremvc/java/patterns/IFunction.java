/*
 PureMVC Java port by Frederic Saunier <frederic.saunier@puremvc.org>
 
 Adapted from sources of thoses different authors :
 	Donald Stinchfield <donald.stinchfield@puremvc.org>, et all
 	Ima OpenSource <opensource@ima.eu>
 	Anthony Quinault <anthony.quinault@puremvc.org>
 
 PureMVC - Copyright(c) 2006-10 Futurescale, Inc., Some rights reserved. 
 Your reuse is governed by the Creative Commons Attribution 3.0 License
 */
package org.puremvc.java.patterns;

import org.puremvc.java.interfaces.INotification;

/**
 * This interface must be implemented by all classes that want to be notified of
 * a notification.
 */
interface IFunction {

	/**
	 * @param notification
	 */
	public void onNotification(INotification notification);
}
