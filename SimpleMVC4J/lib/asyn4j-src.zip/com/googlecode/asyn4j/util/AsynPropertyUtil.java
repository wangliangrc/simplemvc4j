package com.googlecode.asyn4j.util;

public final class AsynPropertyUtil {

}
