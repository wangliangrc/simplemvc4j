package com.googlecode.asyn4j.exception;

/**
 * TODO Comment of Asyn4jException
 * 
 * @author pan_java
 * @version Asyn4jException.java 2010-8-27 下午06:55:31
 */
public class Asyn4jException extends RuntimeException {

    private static final long serialVersionUID = -5275960626115878027L;

    public Asyn4jException(String message) {
        super(message);
    }

}
