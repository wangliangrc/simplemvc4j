package com.googlecode.asyn4j.core.handler;

/**
 * TODO Comment of AsynHandler
 * 
 * @author pan_java
 * @version AsynHandler.java 2010-8-27 下午07:51:44
 */
public interface AsynHandler {
    public void process();
}
