package flexjson;

/**
 * User: brandongoodin Date: Dec 13, 2007 Time: 12:49:06 PM
 */
public enum BasicType {
	OBJECT, ARRAY;
}
